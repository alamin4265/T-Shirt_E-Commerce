import { createResource } from "../utils/http";

export const SignUp_PENDING = "SignUp_PENDING";
export const SignUp_SUCCESS = "SignUp_SUCCESS";
export const SignUp_FAILURE = "SignUp_FAILURE";

const usersUrl = "customers";

const createUserPending = isLoading => ({
  type: SignUp_PENDING,
  isLoading
});

const createUserSuccess = user => ({
  type: SignUp_SUCCESS,
  user
});

const createUserFailure = error => ({
  type: SignUp_FAILURE,
  error
});

export const createUser = user => dispatch => {
  dispatch(createUserPending(true));
  return createResource()
    .then(response => {
      dispatch(createUserPending(false));
      dispatch(createUserSuccess(response.data));
      localStorage.setItem("auth_token", response.data.customer.access_token);
    })
    .catch(err => {
      dispatch(createUserPending(false));
      dispatch(createUserFailure(err.response.data));
    });
};
