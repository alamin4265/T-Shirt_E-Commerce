import { combineReducers } from "redux";
import SignUpReducer from "./signUpReducer";

export default combineReducers({
  SignUpReducer
});
