import * as actions from "../actions/signUpActions";
const initialState = {
  user: {},
  error: null,
  isLoading: false
};

const SignUpReducer = (state = initialState, action) => {
  switch (action.type) {
    case actions.SignUp_PENDING:
      return Object.assign({}, state, { isLoading: action.isLoading });
    case actions.SignUp_SUCCESS:
      return Object.assign({}, state, { user: action.user });
    case actions.SignUp_FAILURE:
      return Object.assign({}, state, { error: action.error });
    default:
      return state;
  }
};

export default SignUpReducer;
